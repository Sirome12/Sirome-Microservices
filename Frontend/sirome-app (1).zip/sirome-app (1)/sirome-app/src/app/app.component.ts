import { Component, OnInit } from '@angular/core';

 
declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'sirome-app';

  ngOnInit(): void {
    $(document).ready(() => {
      // Sidebar toggle behavior
      $('#sidebarCollapse').on('click', function() {
        $('.vertical-nav-content').toggleClass("show");
      });
      
      // Sidebar toggle 
      $('#sidebarClose').on('click', function() {
        $('.vertical-nav-content').toggleClass("show");
      });
    });
  }
}
