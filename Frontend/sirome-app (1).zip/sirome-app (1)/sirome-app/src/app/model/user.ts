export class User {
    id:number;
    name:string;
    lastname:string;
    profile_img_url:string;
    email:string;
    birthday:string;
    password:string;
    subscription_status:boolean;
}

