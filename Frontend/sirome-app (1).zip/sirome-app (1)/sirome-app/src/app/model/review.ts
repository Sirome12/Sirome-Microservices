export class Review {
    id:number;
    title:string;
    summary:string;
    website:string;
    score:number;
    content:string;
    lastModifiedOn:string;
    movieId:number;
    userId:number;
}
