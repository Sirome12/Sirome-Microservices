export class Movie {
	id:number;
	name:string;
    slogan:string;
    trailer:string;
	imdb_id:number;
	sinopsis:string;
	duration:number;
	views:number;
	source:string;
	rental_price:number;
	release_date:string;
	poster_url:string;
	backdrop_url:string;
	gendersIds:any[];
}
