import { Component, OnInit } from '@angular/core';
import { Movie } from 'src/app/model/movie';
import { ApiService } from 'src/app/shared/api.service';

import {ActivatedRoute} from '@angular/router';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {
  [x: string]: any;
  id: Number;
  movie: Movie = new Movie();

  constructor(route: ActivatedRoute, private apiService: ApiService) {
    this.id = Number(route.snapshot.paramMap.get('id'));
  }

  getMovie() {
    this.apiService.getOneMovie(this.id).subscribe(
      res => {
        this.movie = res;
      },
      err => { alert("Error al cargar la pelicula."); }
    );
  }

  deleteMovie() {
    this.apiService.deleteMovie(this.id).subscribe(
      res => {
        alert("Película eliminada con éxito.");
        this.router.navigate(['/home'])
      },
      err => { alert("Error al borrar pelicula."); }
    );
  }


  ngOnInit() {
    this.getMovie();
  }

}
