import { Component, OnInit } from '@angular/core';
import { Movie } from 'src/app/model/movie';
import { Gender } from 'src/app/model/gender';
import { ApiService } from 'src/app/shared/api.service';

@Component({
  selector: 'app-update-movie',
  templateUrl: './update-movie.component.html',
  styleUrls: ['./update-movie.component.css']
})
export class UpdateMovieComponent implements OnInit {
  
  movie: Movie = new Movie();
  genders: Gender[] = [];
  constructor(private apiService: ApiService) { }

  ngOnInit() {
    this.getAllGenders();
  }

  public getAllGenders() {
    this.apiService.getAllGenders().subscribe(
      res => {
        this.genders = res;
      },
      err => {
        alert("Ocurrio un error;")
      }
    );
  }

  postMovie() {

    this.apiService.postMovie(this.movie).subscribe(
      res => {
        this.movie.id = res.id;
        location.reload();

      },
      err => { alert("Ocurrio un error al postear la pelicula"); }
    );

  }

  onSubmit($event) {
    let list: any[];
    list = this.movie.gendersIds.map(function(value) {
      return Number(value);
     });

     this.movie.imdb_id = Number(this.movie.imdb_id);
     this.movie.duration = Number(this.movie.duration);
     this.movie.views = Number(this.movie.views);
     this.movie.rental_price = Number(this.movie.rental_price);
     this.movie.gendersIds = list;
  }
}
