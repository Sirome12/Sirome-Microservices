import { Component, OnInit } from '@angular/core';
import { Movie } from 'src/app/model/movie';
import { Gender } from 'src/app/model/gender';
import { ApiService } from 'src/app/shared/api.service';
import {Router} from "@angular/router"
import { headersToString } from 'selenium-webdriver/http';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userId: Number;
  email: String;
  password: String;
  errorMessage: String = "";
  errors: Boolean = false;
  constructor(private apiService: ApiService, private router: Router) { }

  ngOnInit() {
    
  }

  public login() {
    this.apiService.getUserLogin(this.email, this.password).subscribe(
      res => {
        this.userId = res;
        if (this.userId > 0) {
          this.router.navigate(['/home'])
        } else {
          this.errors = true;
          this.errorMessage = "Password o Email incorrectos";
        }
      },
      err => {
        alert("Ocurrio error.")
      }
    );
  }



}
