import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NavigationComponent } from './navigation/navigation.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { GenderComponent } from './gender/gender.component';
import { MovieComponent } from './movie/movie.component';
import { UpdateMovieComponent } from './movie/update-movie/update-movie.component';
import { LandingComponent } from './landing/landing.component';

const routes: Routes = [
  {
    path:'',
    component:LandingComponent
  },{
  path:'navigation',
  component:NavigationComponent
},
{
  path:'home',
  component:HomeComponent
},
{
  path:'login',
  component:LoginComponent
},
{
  path:'register',
  component:RegisterComponent
},
{
  path:'movie/:id',
  component:MovieComponent
},
{
  path:'gender/:id',
  component:GenderComponent
},
{
  path:'add/movie',
  component:UpdateMovieComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
