import { Movie } from '../model/movie';
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../shared/api.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  movies: Movie[] = [];

  constructor(private apiService: ApiService) { }

  public getAllMovies() {
    this.apiService.getAllMovies().subscribe(
      res => {
        this.movies = res;
      },
      err => {
        alert("Ocurrio un error;")
      }
    );
  }

  ngOnInit() {
    this.getAllMovies();
  }

}
