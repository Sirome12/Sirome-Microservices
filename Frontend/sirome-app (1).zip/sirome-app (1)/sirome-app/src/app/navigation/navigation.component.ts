import { Component, OnInit } from '@angular/core';
import { Gender } from 'src/app/model/gender';
import { ApiService } from 'src/app/shared/api.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {

  genders: Gender[] = [];
  constructor(private apiService: ApiService) { }

  ngOnInit() {
    this.getAllGenders();
  }

  public getAllGenders() {
    this.apiService.getAllGenders().subscribe(
      res => {
        this.genders = res;
      },
      err => {
        alert("Ocurrio un error;")
      }
    );
  }

}
