import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavigationComponent } from './navigation/navigation.component';
import { LoginComponent } from './login/login.component';
import { ReviewComponent } from './review/review.component';
import { MovieComponent } from './movie/movie.component';
import { UserComponent } from './user/user.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';

import {FormsModule} from "@angular/forms";
import {HttpClientModule} from "@angular/common/http";
import { UpdateMovieComponent } from './movie/update-movie/update-movie.component';
import { LandingComponent } from './landing/landing.component';
import { GenderComponent } from './gender/gender.component';
@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    LoginComponent,
    ReviewComponent,
    MovieComponent,
    UserComponent,
    RegisterComponent,
    HomeComponent,
    UpdateMovieComponent,
    LandingComponent,
    GenderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
