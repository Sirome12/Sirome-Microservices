import { Component, OnInit } from '@angular/core';
import { Gender } from 'src/app/model/gender';
import { Movie } from 'src/app/model/movie';
import { ApiService } from 'src/app/shared/api.service';
import {ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-gender',
  templateUrl: './gender.component.html',
  styleUrls: ['./gender.component.css']
})
export class GenderComponent implements OnInit {

  genderId: Number;
  gender: Gender = new Gender();
  movies: Movie[] = [];
  constructor(private apiService: ApiService, route: ActivatedRoute) { 
    this.genderId = Number(route.snapshot.paramMap.get('id'));
  }

  ngOnInit() {
    this.getOneGender();
    this.getMoviesByGenderId();
  }

  public getMoviesByGenderId() {
    this.apiService.getMoviesByGenderId(this.genderId).subscribe(
      res => {
        this.movies = res;
      },
      err => {
        alert("Ocurrio un error;")
      }
    );
  }

  public getOneGender() {
    this.apiService.getOneGender(this.genderId).subscribe(
      res => {
        this.gender = res;
      },
      err => {
        alert("Ocurrio un error;")
      }
    );
  }

}
