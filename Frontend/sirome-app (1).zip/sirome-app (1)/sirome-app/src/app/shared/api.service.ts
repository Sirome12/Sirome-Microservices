import { User } from './../model/user';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Movie } from '../model/movie';
import { Review } from '../model/review';
import { Gender } from '../model/gender';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private BASE_URL = "http://localhost:8097/api";
  public ALL_MOVIES_URL = `${this.BASE_URL}/movies`;
  public ALL_GENDERS_URL = `${this.BASE_URL}/genders`;
  public ONE_MOVIE_URL = `${this.BASE_URL}/movies/`;
  public DELETE_ONE_MOVIE = `${this.BASE_URL}/movies/`;
  public SAVE_MOVIE_URL = `${this.BASE_URL}/movies`;
  public SAVE_USER_URL = `${this.BASE_URL}/users`;
  public API_LOGIN_URL = `${this.BASE_URL}/users/login/`;
  public ONE_GENDER_URL = `${this.BASE_URL}/genders/`;
  public GET_MOVIES_BY_GENDER_ID = `${this.BASE_URL}/movies/byGenderId/`;

  constructor(private http: HttpClient) { }

  getAllMovies(): Observable<Movie[]> {
    return this.http.get<Movie[]>(this.ALL_MOVIES_URL);
  }

  getOneMovie(movieId: Number): Observable<Movie> {
    console.log(this.ONE_MOVIE_URL + movieId);
    return this.http.get<Movie>(this.ONE_MOVIE_URL + movieId);
  }

  getOneGender(genderId: Number): Observable<Movie> {
    return this.http.get<Movie>(this.ONE_GENDER_URL + genderId);
  }

  getMoviesByGenderId(genderId: Number): Observable<Movie[]> {
    return this.http.get<Movie[]>(this.GET_MOVIES_BY_GENDER_ID + genderId);
  }

  getAllGenders(): Observable<Gender[]> {
    return this.http.get<Gender[]>(this.ALL_GENDERS_URL);
  }

  postMovie(movie: Movie): Observable<any> {
    return this.http.post(this.SAVE_MOVIE_URL, movie);
  }

  getUserLogin(email: String, password: String): Observable<any> {
    return this.http.get(this.API_LOGIN_URL + email + "/" + password);
  }

  postUser(user: User): Observable<any> {
    return this.http.post(this.SAVE_USER_URL, user);
  }

  deleteMovie(id: Number): Observable<any> {
    return this.http.delete(this.DELETE_ONE_MOVIE + id);
  }

}
